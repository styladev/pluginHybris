package com.styla.controllers;


import de.hybris.platform.acceleratorstorefrontcommons.controllers.ThirdPartyConstants;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.pages.AbstractPageController;
import de.hybris.platform.acceleratorstorefrontcommons.controllers.util.GlobalMessages;
import de.hybris.platform.cms2.exceptions.CMSItemNotFoundException;
import de.hybris.platform.cms2.model.pages.ContentPageModel;
import de.hybris.platform.cms2.servicelayer.services.CMSSiteService;
import de.hybris.platform.commerceservices.i18n.CommerceCommonI18NService;
import de.hybris.platform.servicelayer.config.ConfigurationService;
import de.hybris.platform.yacceleratorstorefront.controllers.ControllerConstants;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.servlet.HandlerMapping;

import com.styla.constants.StylaConstants;
import com.styla.json.Seo;
import com.styla.service.StylaSeoService;
import com.styla.service.StylaVersionService;


public abstract class AbstractStylaMagazineController extends AbstractPageController
{
	private static final Logger LOG = Logger.getLogger(AbstractStylaMagazineController.class);

	@Autowired
	ConfigurationService configurationService;

	@Autowired
	StylaSeoService stylaSeoService;

	@Autowired
	CMSSiteService cmsSiteService;

	@Autowired
	CommerceCommonI18NService commerceCommonI18NService;

	@Autowired
	StylaVersionService stylaVersionService;

	protected String getViewForConfiguredPage(final String requestMapping, final Model model, final HttpServletRequest request,
			final HttpServletResponse response) throws CMSItemNotFoundException
	{
		// get the part of the mapped path after the magazine-root
		final String restOfMagazinePath = ((String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE))
				.replaceFirst(requestMapping, "");

		String queryParameter = StringUtils.isBlank(restOfMagazinePath) ? "" : restOfMagazinePath;

		if (StringUtils.isNotBlank(request.getQueryString()))
		{
			queryParameter += "?" + request.getQueryString();
		}

		final Seo seo = stylaSeoService.getSeoForUser(getStylaUsername(), queryParameter);
		if (seo != null && seo.getStatus() != null && seo.getStatus().intValue() == HttpServletResponse.SC_NOT_FOUND)
		{
			final ContentPageModel errorPage = getContentPageForLabelOrId(StylaaddonControllerConstants.Views.Pages.ERROR_CMS_PAGE);
			storeCmsPageInModel(model, errorPage);
			setUpMetaDataForContentPage(model, errorPage);

			model.addAttribute(CMS_PAGE_TITLE, seo.getTitle());
			model.addAttribute(ThirdPartyConstants.SeoRobots.META_ROBOTS, ThirdPartyConstants.SeoRobots.NOINDEX_NOFOLLOW);
			GlobalMessages.addErrorMessage(model, "system.error.page.not.found");
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);

			return ControllerConstants.Views.Pages.Error.ErrorNotFoundPage;
		}

		modelSetup(model);
		addSeoContentToModel(seo, model);
		return getViewForPage(model);
	}

	protected void modelSetup(final Model model)
	{
		try
		{
			final ContentPageModel magazinePage = getContentPageForLabelOrId(
					StylaaddonControllerConstants.Views.Pages.STYLA_MAGAZINE_CMS_PAGE);
			storeCmsPageInModel(model, magazinePage);
			setUpMetaDataForContentPage(model, magazinePage);
			model.addAttribute("stylaJsUrl", getJsUrl());
			model.addAttribute("stylaCssUrl", getCssUrl());
			model.addAttribute("dataRootPath", getStylaDataRootPath());
		}
		catch (final CMSItemNotFoundException e)
		{
			LOG.warn(e);
		}
	}

	protected void addSeoContentToModel(final Seo seo, final Model model)
	{
		if (seo != null)
		{
			storeContentPageTitleInModel(model, seo.getTitle());
			model.addAttribute("stylaHtmlHead", seo.getHtml().getHead());
			model.addAttribute("stylaHtmlBody", seo.getHtml().getBody());
		}
	}

	protected String getJsUrl()
	{
		final String username = getStylaUsername();
		String jsUrl = configurationService.getConfiguration().getString(StylaConstants.STYLA_SCRIPTS_BASEURL);
		jsUrl = addTrailingSlash(jsUrl);
		jsUrl += username + ".js?v=" + stylaVersionService.getVersion(username);
		return jsUrl;
	}

	protected String getCssUrl()
	{
		final String username = getStylaUsername();
		String cssUrl = configurationService.getConfiguration().getString(StylaConstants.STYLA_STYLES_BASEURL);
		cssUrl = addTrailingSlash(cssUrl);
		cssUrl += username + ".css?v=" + stylaVersionService.getVersion(username);
		return cssUrl;
	}

	protected String getStylaDataRootPath()
	{
		final String dataRootPath = configurationService.getConfiguration().getString(getStylaDataRootPathPropertyKey());
		if (StringUtils.isBlank(dataRootPath))
		{
			LOG.error("No valid property defined [" + getStylaDataRootPathPropertyKey() + "]");
			return null;
		}

		return dataRootPath;
	}

	private String getStylaDataRootPathPropertyKey()
	{
		if (StringUtils.isNotBlank(cmsSiteService.getCurrentSite().getUid())
				&& StringUtils.isNotBlank(commerceCommonI18NService.getCurrentLanguage().getIsocode()))
		{
			return StylaConstants.STYLA_DATA_ROOT_PATH + "." + getSiteWithLanguage();
		}

		return null;
	}


	private String getStylaUsername()
	{
		final String username = configurationService.getConfiguration().getString(getStylaUsernamePropertyKey());
		if (StringUtils.isBlank(username))
		{
			LOG.error("No valid property defined [" + getStylaUsernamePropertyKey() + "]");
			return null;
		}

		return username;
	}

	private String getStylaUsernamePropertyKey()
	{
		if (StringUtils.isNotBlank(cmsSiteService.getCurrentSite().getUid())
				&& StringUtils.isNotBlank(commerceCommonI18NService.getCurrentLanguage().getIsocode()))
		{
			return StylaConstants.STYLA_USERNAME + "." + getSiteWithLanguage();
		}

		return null;
	}

	private String getSiteWithLanguage()
	{
		return (cmsSiteService.getCurrentSite().getUid() + "." + commerceCommonI18NService.getCurrentLanguage().getIsocode())
				.toLowerCase();
	}

	private String addTrailingSlash(String url)
	{
		if (url.charAt(url.length() - 1) != '/')
		{
			url += '/';
		}
		return url;
	}
}
